'use strict';

module.exports = function () {
    require('boot');
};
